# TaxOS DatePicker

Reusable React + TypeScript + Tailwind date picker based on the approved TaxOS prototype.

## Dependency

```bash
npm install lucide-react
```

No date library is required.

## Core API

```tsx
<DatePicker
  mode="range"
  value={{ from, to }}
  onChange={(next) => setValue(next)}
  presets
/>
```

```tsx
<DatePicker
  mode="single"
  value={date}
  onChange={setDate}
/>
```

## Size

Default:

```tsx
<DatePicker size="md" ... />
```

Smaller variant:

```tsx
<DatePicker size="sm" ... />
```

## Compact mode

Compact removes the duplicated From / To (or Date) field section. The current selection remains visible in the footer.

```tsx
<DatePicker
  mode="range"
  compact
  presets
  value={range}
  onChange={setRange}
/>
```

## Presets

Presets are intentionally available only in `mode="range"`.

Default presets:

```tsx
<DatePicker mode="range" presets ... />
```

Custom presets:

```tsx
const presets = [
  {
    id: "fiscalQuarter",
    label: "Fiscal quarter",
    description: "Current quarter",
    getValue: (today) => ({
      from: "2026-07-01",
      to: "2026-09-30",
    }),
  },
];

<DatePicker mode="range" presets={presets} ... />
```

With presets enabled, the header title becomes the preset dropdown trigger. There are no internal Single / Range mode switches: the parent config determines the mode.

## Useful props

- `mode: "single" | "range"`
- `size?: "sm" | "md"`
- `compact?: boolean`
- `presets?: boolean | DatePickerPreset[]` — range only
- `title?: string`
- `showClear?: boolean`
- `showApply?: boolean`
- `locale?: string`
- `weekStartsOn?: 0 | 1`
- `minDate?: string`
- `maxDate?: string`
- `disabledDates?: string[] | ((date) => boolean)`
- `trigger?: render function`
- `onOpenChange?: (open) => void`
- `onApply?: (...) => void`

## Value format

The component intentionally uses `YYYY-MM-DD` strings rather than JavaScript Date objects. This avoids accidental timezone shifts when sending fiscal filter values to Laravel / Inertia.

Range:

```ts
type DateRangeValue = {
  from: string | null;
  to: string | null;
};
```

Single:

```ts
string | null
```

## Laravel + Inertia example

```tsx
const { data, setData, get } = useForm({
  from: null as string | null,
  to: null as string | null,
});

<DatePicker
  mode="range"
  compact
  presets
  value={{ from: data.from, to: data.to }}
  onChange={(value) => {
    setData("from", value.from);
    setData("to", value.to);
  }}
  onApply={(value) => {
    router.get(route("documents.index"), {
      from: value.from,
      to: value.to,
    }, {
      preserveState: true,
      replace: true,
    });
  }}
/>
```

## Design behavior

- `mode` is configuration, not something the end user switches inside the picker.
- Range presets are optional.
- Clicking the range title opens presets when presets are configured.
- Month/year can be changed quickly from the month label.
- `compact` removes duplicated date fields.
- `size="sm"` reduces spacing and typography slightly without changing the visual language.
- Apply can be disabled with `showApply={false}` for immediate selection behavior.
