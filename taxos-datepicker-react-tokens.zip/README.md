# TaxOS DatePicker

Reusable React + TypeScript + Tailwind date picker based on the approved TaxOS prototype.

## Dependency

```bash
npm install lucide-react
```

No date library is required.

## Core API

```tsx
<DatePicker
  mode="range"
  value={{ from, to }}
  onChange={(next) => setValue(next)}
  presets
/>
```

```tsx
<DatePicker
  mode="single"
  value={date}
  onChange={setDate}
/>
```

## Size

Default:

```tsx
<DatePicker size="md" ... />
```

Smaller variant:

```tsx
<DatePicker size="sm" ... />
```

## Compact mode

Compact removes the duplicated From / To (or Date) field section. The current selection remains visible in the footer.

```tsx
<DatePicker
  mode="range"
  compact
  presets
  value={range}
  onChange={setRange}
/>
```

## Presets

Presets are intentionally available only in `mode="range"`.

Default presets:

```tsx
<DatePicker mode="range" presets ... />
```

Custom presets:

```tsx
const presets = [
  {
    id: "fiscalQuarter",
    label: "Fiscal quarter",
    description: "Current quarter",
    getValue: (today) => ({
      from: "2026-07-01",
      to: "2026-09-30",
    }),
  },
];

<DatePicker mode="range" presets={presets} ... />
```

With presets enabled, the header title becomes the preset dropdown trigger. There are no internal Single / Range mode switches: the parent config determines the mode.

## Useful props

- `mode: "single" | "range"`
- `size?: "sm" | "md"`
- `compact?: boolean`
- `presets?: boolean | DatePickerPreset[]` — range only
- `title?: string`
- `showClear?: boolean`
- `showApply?: boolean`
- `locale?: string`
- `weekStartsOn?: 0 | 1`
- `minDate?: string`
- `maxDate?: string`
- `disabledDates?: string[] | ((date) => boolean)`
- `trigger?: render function`
- `onOpenChange?: (open) => void`
- `onApply?: (...) => void`

## Value format

The component intentionally uses `YYYY-MM-DD` strings rather than JavaScript Date objects. This avoids accidental timezone shifts when sending fiscal filter values to Laravel / Inertia.

Range:

```ts
type DateRangeValue = {
  from: string | null;
  to: string | null;
};
```

Single:

```ts
string | null
```

## Laravel + Inertia example

```tsx
const { data, setData, get } = useForm({
  from: null as string | null,
  to: null as string | null,
});

<DatePicker
  mode="range"
  compact
  presets
  value={{ from: data.from, to: data.to }}
  onChange={(value) => {
    setData("from", value.from);
    setData("to", value.to);
  }}
  onApply={(value) => {
    router.get(route("documents.index"), {
      from: value.from,
      to: value.to,
    }, {
      preserveState: true,
      replace: true,
    });
  }}
/>
```

## Design behavior

- `mode` is configuration, not something the end user switches inside the picker.
- Range presets are optional.
- Clicking the range title opens presets when presets are configured.
- Month/year can be changed quickly from the month label.
- `compact` removes duplicated date fields.
- `size="sm"` reduces spacing and typography slightly without changing the visual language.
- Apply can be disabled with `showApply={false}` for immediate selection behavior.

---

## Colour: tokens, not literals

This version paints with **design tokens** rather than hex values. Nothing looks different today —
every token holds the value the literal used to — but the picker now follows the interface instead
of freezing one version of it.

The reason is the palette switcher. TaxOS changes theme by rewriting CSS custom properties at
runtime (`--brand-500`, `--card`, `--border`…). A literal cannot follow that: with `bg-[#386A96]`
baked in, choosing the Berry palette turned every control on the page crimson and left the date
picker blue. A token is read at paint time, so it just follows.

The same swap removed about thirty `dark:` variants. `--popover` already *is* `#2C2F33` in dark and
`#FFFFFF` in light, so `bg-popover` says in one class what `bg-white dark:bg-[#2C2F33]` said in two —
and says it correctly in every future theme as well.

### What the host application must define

The component assumes these are available as Tailwind colour utilities (in TaxOS they come from
`resources/css/app.css`'s `@theme` block):

| token | used for |
|---|---|
| `--background`, `--foreground` | page ground and primary text |
| `--card`, `--popover`, `--popover-foreground` | the panel and the floating surfaces |
| `--secondary` | hover fills, quiet buttons |
| `--muted-foreground` | weekday letters, out-of-month days, hints |
| `--border` | every hairline |
| `--ring` | the focused trigger's edge |
| `--primary-foreground` | text on a filled brand day |
| `--brand-50` … `--brand-800` | the selected day, the range wash, preset accents |
| `--brand-rgb` | the translucent range wash, as `rgb(var(--brand-rgb)/11%)` |

`--brand-rgb` is the one that needs a word: a range highlight must be see-through so the day number
stays readable, and a translucent colour cannot be mixed from a hex utility. TaxOS publishes the
brand as raw channels alongside the ramp for exactly this.

### Dropping it into a different app

If your app names its tokens differently, the mapping is one-to-one and mechanical — every class in
this file is either a layout utility or one of the names in the table above.

## Strict TypeScript

Three changes make the file compile under `noUncheckedIndexedAccess` and `verbatimModuleSyntax`,
which is what TaxOS runs:

- `parseISO` declares its return type, so destructuring an array does not spread `number | undefined`
  through every caller that does arithmetic on a month.
- `monthName` falls back to the month number when `Intl` rejects a locale *and* the index is out of
  range.
- `ReactNode` is imported as a type.

Two real defects were fixed while porting, both flagged by linting rather than by use:

- `setOpenSafe` was called by a dismiss effect declared **above** it — a temporal-dead-zone read that
  only worked because the effect body runs later. It is declared before its first use now.
- The reset-on-close effect rewrote four pieces of state on every render while the popover was shut,
  which is a cascade waiting for a parent that re-renders often.

## Language

Labels are English in this file. In TaxOS they are expected to come from the dictionary
(`resources/js/i18n`), since the interface is Romanian — the component takes `title`, and the rest
are candidates for props if you want the same treatment.
