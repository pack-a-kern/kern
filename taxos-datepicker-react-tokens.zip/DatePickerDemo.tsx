import React, { useState } from "react";
import { DatePicker, DateRangeValue } from "./DatePicker";

export default function DatePickerDemo() {
  const [range, setRange] = useState<DateRangeValue>({
    from: "2026-09-06",
    to: "2026-09-12",
  });

  const [single, setSingle] = useState<string | null>("2026-09-12");

  return (
    <div className="min-h-screen bg-[#F5F7F9] p-8 text-[#101828] dark:bg-[#191A1C] dark:text-white">
      <div className="mx-auto grid max-w-5xl gap-8 md:grid-cols-2">
        <section>
          <h2 className="mb-3 text-sm font-semibold">Range / default</h2>
          <DatePicker
            mode="range"
            value={range}
            onChange={setRange}
            presets
          />
        </section>

        <section>
          <h2 className="mb-3 text-sm font-semibold">Range / compact / small</h2>
          <DatePicker
            mode="range"
            size="sm"
            compact
            value={range}
            onChange={setRange}
            presets
          />
        </section>

        <section>
          <h2 className="mb-3 text-sm font-semibold">Single / default</h2>
          <DatePicker
            mode="single"
            value={single}
            onChange={setSingle}
          />
        </section>

        <section>
          <h2 className="mb-3 text-sm font-semibold">Single / compact / small</h2>
          <DatePicker
            mode="single"
            size="sm"
            compact
            value={single}
            onChange={setSingle}
          />
        </section>
      </div>
    </div>
  );
}
