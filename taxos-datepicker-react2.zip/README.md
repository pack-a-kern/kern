# TaxOS DatePicker v2

Reusable React + TypeScript + Tailwind date picker.

## Dependency

```bash
npm install lucide-react
```

## Important design decisions

- `mode="single" | "range"` is configured by the parent. There are no internal mode-switch buttons.
- `compact` removes the duplicated Date / From / To fields.
- `size="md" | "sm"` controls density.
- Range presets are optional and open from the header title.
- Clicking the calendar month/year title jumps directly to:
  **Decades → Years → Months → Calendar**
- Date boundaries constrain both date selection and navigation.

## Date limits

Both accept a `YYYY-MM-DD` value or `"today"`:

```tsx
<DatePicker
  mode="range"
  minDate="2000-01-01"
  maxDate="today"
  ...
/>
```

This means:
- dates before 2000 are disabled
- future dates are disabled
- month arrows stop at the limits
- months outside the limits are disabled
- years outside the limits are disabled
- decades outside the limits are disabled

So a picker configured for 1900–today will not let the user navigate into 1500.

### Convenience props

```tsx
<DatePicker disableFuture ... />
<DatePicker disablePast ... />
```

They are combined with `minDate` / `maxDate`.

For example:

```tsx
<DatePicker
  minDate="2000-01-01"
  disableFuture
  ...
/>
```

means `2000-01-01` through today.

## Disable month/year hierarchy

If you do not want long-range month/year navigation:

```tsx
<DatePicker
  monthYearNavigation={false}
  ...
/>
```

Then the center `September 2026` text is static. Previous/next month arrows still work and still respect min/max boundaries.

## Long-range navigation

Default behavior:

1. Calendar: `September 2026`
2. Click title → decade blocks
3. Pick `1980s`
4. Pick `1980`
5. Pick `Sep`
6. Back to September 1980 calendar

No repeated year clicking.

## Range example

```tsx
const [range, setRange] = useState({
  from: "2026-09-01",
  to: "2026-09-12",
});

<DatePicker
  mode="range"
  value={range}
  onChange={setRange}
  presets
  minDate="2000-01-01"
  maxDate="today"
/>
```

## Single / compact / small

```tsx
<DatePicker
  mode="single"
  size="sm"
  compact
  value={date}
  onChange={setDate}
  minDate="1900-01-01"
  disableFuture
/>
```

## Props

```ts
mode: "single" | "range"
size?: "sm" | "md"
compact?: boolean
title?: string
locale?: string
weekStartsOn?: 0 | 1

minDate?: string | "today"
maxDate?: string | "today"
disableFuture?: boolean
disablePast?: boolean
disabledDates?: string[] | ((date: string) => boolean)

monthYearNavigation?: boolean

showClear?: boolean
showApply?: boolean
disabled?: boolean

presets?: boolean | DatePickerPreset[] // range only
onOpenChange?: (open: boolean) => void
onApply?: (...)
```

## Value format

Dates use `YYYY-MM-DD` strings, intentionally avoiding timezone shifts.

Single:

```ts
string | null
```

Range:

```ts
type DateRangeValue = {
  from: string | null;
  to: string | null;
};
```

## Laravel + Inertia

```tsx
<DatePicker
  mode="range"
  compact
  presets
  minDate="2000-01-01"
  maxDate="today"
  value={{
    from: data.from,
    to: data.to,
  }}
  onChange={(value) => {
    setData("from", value.from);
    setData("to", value.to);
  }}
  onApply={(value) => {
    router.get(
      route("documents.index"),
      {
        from: value.from,
        to: value.to,
      },
      {
        preserveState: true,
        replace: true,
      }
    );
  }}
/>
```
