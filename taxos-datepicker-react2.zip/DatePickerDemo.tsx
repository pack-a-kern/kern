import React, { useState } from "react";
import { DatePicker, DateRangeValue } from "./DatePicker";

export default function DatePickerDemo() {
  const [range, setRange] = useState<DateRangeValue>({
    from: "2026-09-06",
    to: "2026-09-12",
  });

  const [single, setSingle] = useState<string | null>("1980-09-12");

  return (
    <div className="min-h-screen bg-[#F5F7F9] p-8 text-[#101828] dark:bg-[#191A1C] dark:text-white">
      <div className="mx-auto grid max-w-5xl gap-10 md:grid-cols-2">
        <section>
          <h2 className="mb-3 text-sm font-semibold">
            Range · no future dates · 2000+
          </h2>

          <DatePicker
            mode="range"
            value={range}
            onChange={setRange}
            presets
            minDate="2000-01-01"
            maxDate="today"
          />
        </section>

        <section>
          <h2 className="mb-3 text-sm font-semibold">
            Single · historical · 1900–today
          </h2>

          <DatePicker
            mode="single"
            size="sm"
            compact
            value={single}
            onChange={setSingle}
            minDate="1900-01-01"
            disableFuture
          />
        </section>

        <section>
          <h2 className="mb-3 text-sm font-semibold">
            Month/year hierarchy disabled
          </h2>

          <DatePicker
            mode="range"
            compact
            value={range}
            onChange={setRange}
            minDate="2020-01-01"
            maxDate="today"
            monthYearNavigation={false}
          />
        </section>

        <section>
          <h2 className="mb-3 text-sm font-semibold">
            Immediate selection · max today
          </h2>

          <DatePicker
            mode="single"
            value={single}
            onChange={setSingle}
            maxDate="today"
            showApply={false}
          />
        </section>
      </div>
    </div>
  );
}
